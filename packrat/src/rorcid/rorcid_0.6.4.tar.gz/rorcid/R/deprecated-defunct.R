#' This function is defunct.
#' @export
#' @rdname summary.or_cid-defunct
#' @keywords internal
summary.or_cid <- function(object, ...) {
  .Defunct(msg = "summary.or_cid is defunct")
}
